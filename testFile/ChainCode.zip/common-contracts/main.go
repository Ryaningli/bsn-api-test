package main

import (
	"github.com/hyperledger/fabric-contract-api-go/contractapi"
)

func main() {
	commonDataContract := new(CommonDataContract)
	commonDataContract.TransactionContextHandler = new(CustomTransactionContext)
	commonDataContract.BeforeTransaction = GetWorldState
	commonDataContract.AfterTransaction = SendTxEvent
	commonDataContract.Name = "commonOrg.CommonDataContract"
	commonDataContract.UnknownTransaction = UnknownTransactionHandler

	cc, err := contractapi.NewChaincode(commonDataContract)
	cc.DefaultContract = commonDataContract.GetName()

	if err != nil {
		panic(err.Error())
	}

	if err := cc.Start(); err != nil {
		panic(err.Error())
	}
}
