package main

import "fmt"

func SendEvent(ctx CustomTransactionContextInterface, eventName string, eventPayload []byte) error {
	err := ctx.GetStub().SetEvent(eventName, eventPayload)
	if err != nil {
		return fmt.Errorf("SetEvent %s failure:%s", eventName, err.Error())
	}

	return nil
}
